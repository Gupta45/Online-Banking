package br.com.carlosjunior.registrationlogin.repositories;

import org.springframework.data.repository.CrudRepository;

import br.com.carlosjunior.registrationlogin.entities.SavingsAccount;

public interface SavingsAccountDao extends CrudRepository<SavingsAccount, Long> {

    SavingsAccount findByAccountNumber(int accountNumber);
}