package br.com.carlosjunior.registrationlogin.services;

import java.security.Principal;

import br.com.carlosjunior.registrationlogin.entities.PrimaryAccount;
import br.com.carlosjunior.registrationlogin.entities.SavingsAccount;

public interface AccountService {

    PrimaryAccount createPrimaryAccount();

    SavingsAccount createSavingsAccount();

    void deposit(String accountType, double amount, Principal principal);

    void withdraw(String accountType, double amount, Principal principal);

}