package br.com.carlosjunior.registrationlogin.repositories;

import org.springframework.data.repository.CrudRepository;

import br.com.carlosjunior.registrationlogin.entities.SavingsTransaction;

import java.util.List;

public interface SavingsTransactionDao extends CrudRepository<SavingsTransaction, Long> {

    List<SavingsTransaction> findAll();
}